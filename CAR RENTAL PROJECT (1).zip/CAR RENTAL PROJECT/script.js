// ============================================
// BB RENTALS - LOCAL STORAGE LOGIN SYSTEM
// ============================================


// ADMIN ACCOUNT
// This account is already available.

const ADMIN_EMAIL = "admin@bbrentals.com";
const ADMIN_PASSWORD = "admin123";


// ============================================
// CREATE ACCOUNT
// ============================================

function createAccount(event) {

    event.preventDefault();

    const username = document.getElementById("username").value.trim();
    const email = document.getElementById("new-email").value.trim();
    const phone = document.getElementById("phone").value.trim();
    const password = document.getElementById("new-password").value;
    const confirmPassword =
        document.getElementById("confirm-password").value;


    // Check all fields

    if (
        username === "" ||
        email === "" ||
        phone === "" ||
        password === "" ||
        confirmPassword === ""
    ) {

        alert("Please fill in all fields.");

        return;
    }


    // Check password

    if (password !== confirmPassword) {

        alert("Password and Confirm Password do not match.");

        return;
    }


    // Get existing users

    let users =
        JSON.parse(localStorage.getItem("bbRentalsUsers")) || [];


    // Check whether email already exists

    const existingUser = users.find(
        user => user.email.toLowerCase() === email.toLowerCase()
    );


    if (existingUser) {

        alert("An account with this email already exists.");

        return;
    }


    // Do not allow creating an account using admin email

    if (email.toLowerCase() === ADMIN_EMAIL.toLowerCase()) {

        alert("This email is reserved for the Admin account.");

        return;
    }


    // Create new user

    const newUser = {

        username: username,

        email: email,

        phone: phone,

        password: password

    };


    // Add user to array

    users.push(newUser);


    // Save users in browser localStorage

    localStorage.setItem(
        "bbRentalsUsers",
        JSON.stringify(users)
    );


    alert("Account created successfully!");


    // Go back to login page

    window.location.href = "login.html";

}



// ============================================
// LOGIN
// ============================================

function loginUser(event) {

    event.preventDefault();


    const email =
        document.getElementById("login-email").value.trim();

    const password =
        document.getElementById("login-password").value;


    if (email === "" || password === "") {

        alert("Please enter your email and password.");

        return;
    }


    // ========================================
    // CHECK ADMIN ACCOUNT
    // ========================================

    if (
        email.toLowerCase() === ADMIN_EMAIL.toLowerCase() &&
        password === ADMIN_PASSWORD
    ) {


        // Store logged-in information

        localStorage.setItem(
            "bbRentalsLoggedInUser",
            JSON.stringify({

                username: "Administrator",

                email: ADMIN_EMAIL,

                role: "admin"

            })
        );


        alert("Admin login successful!");


        // Admin page

        window.location.href = "admin.html";

        return;
    }



    // ========================================
    // CHECK NORMAL USERS
    // ========================================

    const users =
        JSON.parse(localStorage.getItem("bbRentalsUsers")) || [];


    const user = users.find(

        user =>
            user.email.toLowerCase() === email.toLowerCase() &&
            user.password === password

    );


    if (!user) {

        alert("Invalid email or password.");

        return;
    }


    // Store logged-in user

    localStorage.setItem(

        "bbRentalsLoggedInUser",

        JSON.stringify({

            username: user.username,

            email: user.email,

            phone: user.phone,

            role: "user"

        })

    );


    alert("Login successful!");


    // Normal user page

    window.location.href = "index.html";

}